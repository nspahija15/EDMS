<?php
/**
 * Created by PhpStorm.
 * User: archey
 * Date: 26.05.18
 * Time: 11:52
 */

namespace AppBundle\Utils;


class ManageAcademicYear
{


    public function __construct()
    {


    }




}