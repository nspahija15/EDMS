<?php 

header('location: ./web/app.php');
die;
