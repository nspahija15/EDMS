#!/usr/bin/env bash

/usr/bin/python2.7 /home/archey/Desktop/Projects/PythonProject/Entrance_Security/start_.py
